﻿using System.Data;
using System.Data.SqlClient;

namespace VMGTechnicalAssessment
{
    public class SQLClientManager
    {
        private SqlConnection m_sqlConnection;
        private static int m_timeout = 30;

        public void Connect(string connectionString)
        {
            if (m_sqlConnection == null)
                m_sqlConnection = new SqlConnection(connectionString);

            if (m_sqlConnection.State != ConnectionState.Open) {
                m_sqlConnection.Open();
            }
        }
        public void Disconnect()
        {
            m_sqlConnection.Close();
        }
        public void ExecuteQuery(string query)
        {
            if (m_sqlConnection == null)
                return;

            SqlCommand sqlCommand = m_sqlConnection.CreateCommand();
            sqlCommand.CommandTimeout = m_timeout;
            sqlCommand.CommandText = query;
            sqlCommand.ExecuteNonQuery();
        }
        public void ExecuteQuery(string query, out DataTable table)
        {
            DataTable dataTable = new DataTable();

            if (m_sqlConnection == null) {
                table = dataTable;
                return;
            }
            SqlCommand sqlCommand = m_sqlConnection.CreateCommand();
            sqlCommand.CommandTimeout = m_timeout;
            sqlCommand.CommandText = query;

            SqlDataAdapter sqlAdapter = new SqlDataAdapter(sqlCommand);
            sqlAdapter.Fill(dataTable);
            table = dataTable;
        }
    }
}
