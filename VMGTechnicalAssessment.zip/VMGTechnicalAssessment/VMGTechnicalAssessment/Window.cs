﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace VMGTechnicalAssessment
{
    public partial class Window : Form
    {
        private static SQLClientManager sqlClientManager = new SQLClientManager();
        private static DateTime m_selectedDate;
        private static bool isInEditMode = false;

        public Window()
        {
            InitializeComponent();
        }

        private void Window_Load(object sender, EventArgs e)
        {
            this.calendar.DateChanged += Calendar_DateChanged;
            UpdateUI();
        }

        private void Calendar_DateChanged(object sender, DateRangeEventArgs e)
        {
            m_selectedDate = e.End;
        }
        private void btnEditBooking_Click(object sender, EventArgs e)
        {
            isInEditMode = !isInEditMode;
            UpdateUI();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            PerformSearch();
            txtSearch.Text = string.Empty;
        }

        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) {
                PerformSearch();
                txtSearch.Text = string.Empty;
            }
        }
        private void Window_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.calendar.DateChanged -= Calendar_DateChanged;
        }

        private void lbxBookings_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (isInEditMode == true) {
                UpdateUI();
            }
        }

        private void btnViewBookings_Click(object sender, EventArgs e)
        {
            UpdateUI();
        }

        private void btnAddBooking_Click(object sender, EventArgs e)
        {
            if (IsValidUserEnteredBookingFields() == false) {
                MessageBox.Show("Please fill all required fields before proceeding.");
                return;
            }

            var bookingDate = m_selectedDate.ToShortDateString();

            if (isInEditMode == false) {
                string query = string.Concat("INSERT INTO Table_Bookings (FirstName,VehicleModel,Date,ServiceType) VALUES('"
                    + Sanatize(txtFirstname.Text) + "'"
                    , ",'" + Sanatize(cboxVehicleModels.Text) + "'"
                    , ",'" + Sanatize(bookingDate) + "'"
                    , ",'" + Sanatize(rtxtNotes.Text) + "')");

                sqlClientManager.Connect(Properties.Settings.Default.WorkshopDatabaseConnectionString);
                sqlClientManager.ExecuteQuery(query);
                sqlClientManager.Disconnect();
            } else {

                if (lbxBookings.Items.Count < 1 || lbxBookings.SelectedItem == null) {
                    return;
                }
                var selectedBooking = (lbxBookings.SelectedItem as DataRowView);
                if (selectedBooking != null) {
                    string bookingId = selectedBooking["Id"].ToString();

                    sqlClientManager.Connect(Properties.Settings.Default.WorkshopDatabaseConnectionString);

                    string query = string.Concat("UPDATE Table_Bookings SET [FirstName] = '" + Sanatize(txtFirstname.Text) + "' WHERE Id = " + bookingId);
                    sqlClientManager.ExecuteQuery(query);

                    query = string.Concat("UPDATE Table_Bookings SET [VehicleModel] = '" + Sanatize(cboxVehicleModels.Text) + "' WHERE Id = " + bookingId);
                    sqlClientManager.ExecuteQuery(query);

                    query = string.Concat("UPDATE Table_Bookings SET [Date] = '" + Sanatize(bookingDate) + "' WHERE Id = " + bookingId);
                    sqlClientManager.ExecuteQuery(query);

                    query = string.Concat("UPDATE Table_Bookings SET [ServiceType] = '" + Sanatize(rtxtNotes.Text) + "' WHERE Id = " + bookingId);
                    sqlClientManager.ExecuteQuery(query);

                    sqlClientManager.Disconnect();

                    isInEditMode = false;
                }
            }
            UpdateUI();
        }

        private void btnRemoveBooking_Click(object sender, EventArgs e)
        {
            if (lbxBookings.Items.Count < 1 || lbxBookings.SelectedItem == null) {
                return;
            }
            var selectedBooking = (lbxBookings.SelectedItem as DataRowView);
            if (selectedBooking != null) {
                string bookingId = selectedBooking["Id"].ToString();
                sqlClientManager.Connect(Properties.Settings.Default.WorkshopDatabaseConnectionString);
                sqlClientManager.ExecuteQuery("DELETE FROM Table_Bookings WHERE(Id = " + bookingId + ")");
                sqlClientManager.Disconnect();
            }

            UpdateUI();
        }

        private void UpdateUI()
        {
            calendar.SetDate(DateTime.Today);
            m_selectedDate = calendar.TodayDate;

            txtSearch.Text = string.Empty;

            if (isInEditMode == false) {

                LoadVehicleModels();
                LoadBookings();

                txtFirstname.Text = string.Empty;
                rtxtNotes.Text = string.Empty;
                txtSearch.Text = string.Empty;

                btnAddBooking.Text = "Add Booking";

                btnEditBooking.Text = "Edit Mode OFF";
                btnEditBooking.BackColor = Color.WhiteSmoke;
            } else {

                if (lbxBookings.Items.Count < 1 || lbxBookings.SelectedItem == null) {
                    return;
                }

                var selectedRow = (lbxBookings.SelectedItem as DataRowView);
                if (selectedRow != null) {

                    txtFirstname.Text = selectedRow["FirstName"].ToString();
                    calendar.TodayDate = DateTime.Parse(selectedRow["Date"].ToString());
                    rtxtNotes.Text = selectedRow["ServiceType"].ToString();
                    cboxVehicleModels.SelectedIndex = FindIndexForVehicle(selectedRow["VehicleModel"].ToString());
                    btnAddBooking.Text = "Save Changes";

                    btnEditBooking.Text = "Edit Mode ON";
                    btnEditBooking.BackColor = Color.OrangeRed;
                }
            }
            btnEditBooking.Enabled = lbxBookings.SelectedItem != null;
            btnRemoveBooking.Enabled = (lbxBookings.SelectedItem != null && isInEditMode == false);
        }

        private void LoadVehicleModels()
        {
            cboxVehicleModels.DisplayMember = "VehicleModel";
            cboxVehicleModels.ValueMember = "Id";
            cboxVehicleModels.DataSource = TableFromQuery("SELECT VehicleModel FROM Table_VehicleModels");
        }
        private void LoadBookings()
        {
            lbxBookings.DisplayMember = "FirstName";
            lbxBookings.ValueMember = "Id";
            var values = TableFromQuery("SELECT * FROM Table_Bookings");
            lbxBookings.DataSource = values;
        }
        private void PerformSearch()
        {
            lbxBookings.DisplayMember = "FirstName";
            lbxBookings.ValueMember = "Id";
            lbxBookings.DataSource = TableFromQuery("SELECT * FROM Table_Bookings WHERE FirstName LIKE '" + txtSearch.Text + "%'");
        }
        private string Sanatize(string stringValue)
        {
            return stringValue.Trim(' ');
        }
        private static DataTable TableFromQuery(string query)
        {
            DataTable dataTable;
            sqlClientManager.Connect(Properties.Settings.Default.WorkshopDatabaseConnectionString);
            sqlClientManager.ExecuteQuery(query, out dataTable);
            sqlClientManager.Disconnect();
            return dataTable;
        }
        private bool IsValidUserEnteredBookingFields()
        {
            return (string.IsNullOrWhiteSpace(m_selectedDate.ToString()) == false
                && string.IsNullOrWhiteSpace(txtFirstname.Text) == false
                && string.IsNullOrWhiteSpace(rtxtNotes.Text) == false
                && string.IsNullOrWhiteSpace(cboxVehicleModels.Text) == false);
        }

        private int FindIndexForVehicle(string name)
        {
            for (int i = 0; i < cboxVehicleModels.Items.Count; i++) {
                var value = (cboxVehicleModels.Items[i] as DataRowView)[0].ToString();
                if (value == name) {
                    return i;
                }
            }
            return 0;
        }

    }
}
