﻿namespace VMGTechnicalAssessment
{
    partial class Window
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelMain = new System.Windows.Forms.Panel();
            this.calendar = new System.Windows.Forms.MonthCalendar();
            this.btnSearch = new System.Windows.Forms.Button();
            this.cboxVehicleModels = new System.Windows.Forms.ComboBox();
            this.lbxBookings = new System.Windows.Forms.ListBox();
            this.lblNotes = new System.Windows.Forms.Label();
            this.lblSearch = new System.Windows.Forms.Label();
            this.lblVehicleModel = new System.Windows.Forms.Label();
            this.lblBookingDate = new System.Windows.Forms.Label();
            this.lblHeader = new System.Windows.Forms.Label();
            this.lblFirstname = new System.Windows.Forms.Label();
            this.btnEditBooking = new System.Windows.Forms.Button();
            this.btnRemoveBooking = new System.Windows.Forms.Button();
            this.btnAddBooking = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.rtxtNotes = new System.Windows.Forms.RichTextBox();
            this.txtFirstname = new System.Windows.Forms.TextBox();
            this.btnViewBookings = new System.Windows.Forms.Button();
            this.lblBookings = new System.Windows.Forms.Label();
            this.panelMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelMain
            // 
            this.panelMain.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panelMain.Controls.Add(this.lblBookings);
            this.panelMain.Controls.Add(this.btnViewBookings);
            this.panelMain.Controls.Add(this.calendar);
            this.panelMain.Controls.Add(this.btnSearch);
            this.panelMain.Controls.Add(this.cboxVehicleModels);
            this.panelMain.Controls.Add(this.lbxBookings);
            this.panelMain.Controls.Add(this.lblNotes);
            this.panelMain.Controls.Add(this.lblSearch);
            this.panelMain.Controls.Add(this.lblVehicleModel);
            this.panelMain.Controls.Add(this.lblBookingDate);
            this.panelMain.Controls.Add(this.lblHeader);
            this.panelMain.Controls.Add(this.lblFirstname);
            this.panelMain.Controls.Add(this.btnEditBooking);
            this.panelMain.Controls.Add(this.btnRemoveBooking);
            this.panelMain.Controls.Add(this.btnAddBooking);
            this.panelMain.Controls.Add(this.txtSearch);
            this.panelMain.Controls.Add(this.rtxtNotes);
            this.panelMain.Controls.Add(this.txtFirstname);
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMain.Location = new System.Drawing.Point(0, 0);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(784, 562);
            this.panelMain.TabIndex = 0;
            // 
            // calendar
            // 
            this.calendar.BackColor = System.Drawing.SystemColors.Window;
            this.calendar.Location = new System.Drawing.Point(116, 154);
            this.calendar.Name = "calendar";
            this.calendar.TabIndex = 16;
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(522, 68);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(206, 24);
            this.btnSearch.TabIndex = 15;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // cboxVehicleModels
            // 
            this.cboxVehicleModels.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboxVehicleModels.FormattingEnabled = true;
            this.cboxVehicleModels.Location = new System.Drawing.Point(116, 110);
            this.cboxVehicleModels.Name = "cboxVehicleModels";
            this.cboxVehicleModels.Size = new System.Drawing.Size(227, 21);
            this.cboxVehicleModels.TabIndex = 14;
            // 
            // lbxBookings
            // 
            this.lbxBookings.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbxBookings.FormattingEnabled = true;
            this.lbxBookings.Location = new System.Drawing.Point(522, 176);
            this.lbxBookings.Name = "lbxBookings";
            this.lbxBookings.Size = new System.Drawing.Size(206, 197);
            this.lbxBookings.TabIndex = 13;
            this.lbxBookings.SelectedIndexChanged += new System.EventHandler(this.lbxBookings_SelectedIndexChanged);
            // 
            // lblNotes
            // 
            this.lblNotes.AutoSize = true;
            this.lblNotes.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNotes.Location = new System.Drawing.Point(12, 338);
            this.lblNotes.Name = "lblNotes";
            this.lblNotes.Size = new System.Drawing.Size(40, 13);
            this.lblNotes.TabIndex = 12;
            this.lblNotes.Text = "Notes";
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearch.Location = new System.Drawing.Point(561, 27);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(116, 13);
            this.lblSearch.TabIndex = 11;
            this.lblSearch.Text = "Search for Booking";
            // 
            // lblVehicleModel
            // 
            this.lblVehicleModel.AutoSize = true;
            this.lblVehicleModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVehicleModel.Location = new System.Drawing.Point(12, 110);
            this.lblVehicleModel.Name = "lblVehicleModel";
            this.lblVehicleModel.Size = new System.Drawing.Size(87, 13);
            this.lblVehicleModel.TabIndex = 10;
            this.lblVehicleModel.Text = "Vehicle Model";
            // 
            // lblBookingDate
            // 
            this.lblBookingDate.AutoSize = true;
            this.lblBookingDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBookingDate.Location = new System.Drawing.Point(12, 154);
            this.lblBookingDate.Name = "lblBookingDate";
            this.lblBookingDate.Size = new System.Drawing.Size(84, 13);
            this.lblBookingDate.TabIndex = 9;
            this.lblBookingDate.Text = "Booking Date";
            // 
            // lblHeader
            // 
            this.lblHeader.AutoSize = true;
            this.lblHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeader.Location = new System.Drawing.Point(113, 23);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(191, 20);
            this.lblHeader.TabIndex = 8;
            this.lblHeader.Text = "Worksop Booking System";
            // 
            // lblFirstname
            // 
            this.lblFirstname.AutoSize = true;
            this.lblFirstname.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirstname.Location = new System.Drawing.Point(12, 79);
            this.lblFirstname.Name = "lblFirstname";
            this.lblFirstname.Size = new System.Drawing.Size(61, 13);
            this.lblFirstname.TabIndex = 7;
            this.lblFirstname.Text = "Firstname";
            // 
            // btnEditBooking
            // 
            this.btnEditBooking.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnEditBooking.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEditBooking.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditBooking.Location = new System.Drawing.Point(522, 391);
            this.btnEditBooking.Name = "btnEditBooking";
            this.btnEditBooking.Size = new System.Drawing.Size(206, 30);
            this.btnEditBooking.TabIndex = 6;
            this.btnEditBooking.Text = "Edit Booking";
            this.btnEditBooking.UseVisualStyleBackColor = false;
            this.btnEditBooking.Click += new System.EventHandler(this.btnEditBooking_Click);
            // 
            // btnRemoveBooking
            // 
            this.btnRemoveBooking.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnRemoveBooking.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRemoveBooking.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemoveBooking.Location = new System.Drawing.Point(522, 427);
            this.btnRemoveBooking.Name = "btnRemoveBooking";
            this.btnRemoveBooking.Size = new System.Drawing.Size(206, 30);
            this.btnRemoveBooking.TabIndex = 5;
            this.btnRemoveBooking.Text = "Remove Booking";
            this.btnRemoveBooking.UseVisualStyleBackColor = false;
            this.btnRemoveBooking.Click += new System.EventHandler(this.btnRemoveBooking_Click);
            // 
            // btnAddBooking
            // 
            this.btnAddBooking.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnAddBooking.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddBooking.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddBooking.Location = new System.Drawing.Point(116, 427);
            this.btnAddBooking.Name = "btnAddBooking";
            this.btnAddBooking.Size = new System.Drawing.Size(227, 30);
            this.btnAddBooking.TabIndex = 4;
            this.btnAddBooking.Text = "Add Booking";
            this.btnAddBooking.UseVisualStyleBackColor = false;
            this.btnAddBooking.Click += new System.EventHandler(this.btnAddBooking_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSearch.Location = new System.Drawing.Point(522, 43);
            this.txtSearch.MaxLength = 25;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(206, 20);
            this.txtSearch.TabIndex = 3;
            this.txtSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSearch_KeyDown);
            // 
            // rtxtNotes
            // 
            this.rtxtNotes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rtxtNotes.Location = new System.Drawing.Point(116, 335);
            this.rtxtNotes.MaxLength = 25;
            this.rtxtNotes.Name = "rtxtNotes";
            this.rtxtNotes.Size = new System.Drawing.Size(227, 72);
            this.rtxtNotes.TabIndex = 2;
            this.rtxtNotes.Tag = "";
            this.rtxtNotes.Text = "";
            // 
            // txtFirstname
            // 
            this.txtFirstname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFirstname.Location = new System.Drawing.Point(116, 79);
            this.txtFirstname.MaxLength = 25;
            this.txtFirstname.Name = "txtFirstname";
            this.txtFirstname.Size = new System.Drawing.Size(227, 20);
            this.txtFirstname.TabIndex = 0;
            this.txtFirstname.Tag = "";
            // 
            // btnViewBookings
            // 
            this.btnViewBookings.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnViewBookings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnViewBookings.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewBookings.Location = new System.Drawing.Point(522, 99);
            this.btnViewBookings.Name = "btnViewBookings";
            this.btnViewBookings.Size = new System.Drawing.Size(206, 24);
            this.btnViewBookings.TabIndex = 17;
            this.btnViewBookings.Text = "View All Bookings";
            this.btnViewBookings.UseVisualStyleBackColor = false;
            this.btnViewBookings.Click += new System.EventHandler(this.btnViewBookings_Click);
            // 
            // lblBookings
            // 
            this.lblBookings.AutoSize = true;
            this.lblBookings.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBookings.Location = new System.Drawing.Point(584, 154);
            this.lblBookings.Name = "lblBookings";
            this.lblBookings.Size = new System.Drawing.Size(59, 13);
            this.lblBookings.TabIndex = 18;
            this.lblBookings.Text = "Bookings";
            // 
            // Window
            // 
            this.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(784, 562);
            this.Controls.Add(this.panelMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Window";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "VMG Software 2019";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Window_FormClosing);
            this.Load += new System.EventHandler(this.Window_Load);
            this.panelMain.ResumeLayout(false);
            this.panelMain.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Label lblNotes;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.Label lblVehicleModel;
        private System.Windows.Forms.Label lblBookingDate;
        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.Label lblFirstname;
        private System.Windows.Forms.Button btnEditBooking;
        private System.Windows.Forms.Button btnRemoveBooking;
        private System.Windows.Forms.Button btnAddBooking;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.RichTextBox rtxtNotes;
        private System.Windows.Forms.TextBox txtFirstname;
        private System.Windows.Forms.ListBox lbxBookings;
        private System.Windows.Forms.ComboBox cboxVehicleModels;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.MonthCalendar calendar;
        private System.Windows.Forms.Button btnViewBookings;
        private System.Windows.Forms.Label lblBookings;
    }
}

